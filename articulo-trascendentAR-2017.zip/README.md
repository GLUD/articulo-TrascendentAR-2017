# articulo-individual-2017
Plantilla de Artículo Invididual Revista Colibrí GLUD 2017
